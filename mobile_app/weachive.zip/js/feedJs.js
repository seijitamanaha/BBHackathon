/*
 *	BlackBerry 10 OS Tablet App - Hackathon Campinas / Brazil
 *  App: 		"App Name"
 *	Authors:	Andre Vitor Terron
 *				Andre Seiji Tamanaha
 *				Thiago Yukio Itagaki
 *	Version: 	1.0.0.0
 *	Data: 		15/09/2012
 */

/*
 ****	FEED.html JS
 */

// Recebe os Feeds em RealTime
/*var feedSource = new EventSource("");
feedSource.onmessage = function(event){
	var feedData = null;
	$("#newsfeed").prepend();
}*/
function addFeed(){
	
}

// Ao clicar em um feed
$(".feed").live("click",function(){
	//...
});

$(document).read(addFeed);