/*
 *	BlackBerry 10 OS Tablet App - Hackathon Campinas / Brazil
 *  App: 		"App Name"
 *	Authors:	Andre Vitor Terron
 *				Andre Seiji Tamanaha
 *				Thiago Yukio Itagaki
 *	Version: 	1.0.0.0
 *	Data: 		15/09/2012
 */

/*
 ****	JD DATA
 */
 
localStorage.setItem("fakeLogin","blackberry");
localStorage.setItem("fakePass","1234");
localStorage.setItem("fakeID","1");

localStorage.setItem("fakeTarefaTitulo1","Coler 10km");
localStorage.setItem("fakeTarefaData1","20/09/2012");
localStorage.setItem("fakeTarefaTitulo2","Pegar o Coelhinho da Mônica");
localStorage.setItem("fakeTarefaData2","15/09/2012");